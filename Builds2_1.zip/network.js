/*
Used to set the network
1 Mainnet
3 Ropsten
4 Rinkeby
5 Goerli
42 Kovan
56 Binance Smart Chain Mainnet
97 Binance Smart Chain Testnet
100 xDai
137 Matic
1287 Moonbase Testnet
80001 Matic Testnet
43113 Avalanche Testnet
43114 Avalanche Mainnet
42220 Celo Mainnet
44787 Celo Alfajores Testnet
62320 Celo Baklava Testnet
1666700000 Harmony Testnet Shard0
1666600000 Harmony Mainnet Shard0
*/

window.web3NetworkId = 4;
window.infuraKey = "2d0062a43e9e4086829df115488b45a8";
